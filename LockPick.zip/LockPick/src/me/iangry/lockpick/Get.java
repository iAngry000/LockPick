package me.iangry.lockpick;

import java.util.ArrayList;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

    public class Get implements CommandInterface {

        public boolean onCommand(CommandSender sender, Command cmd, String commandLabel, String[] args) {
        if (args.length < 2) return false;
        if (sender.hasPermission("lockpick.give")) {
            String playerName = args[1];
            Player target = sender.getServer().getPlayerExact(playerName);
            if (target == null) {
                sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&2[&aLockPick&2]"));
                sender.sendMessage("�a" + playerName + " is not online");
                return true;
            }
            ItemStack is = new ItemStack(Material.getMaterial(Main.getInstance().getConfig().getString("lock-pick-item")));
            ItemMeta im = is.getItemMeta();
            im.setDisplayName(ChatColor.translateAlternateColorCodes('&', Main.getInstance().getConfig().getString("lock-pick-name")));
            im.addItemFlags(ItemFlag.HIDE_ENCHANTS);
            im.addEnchant(Enchantment.DAMAGE_ALL, 1, true);
            ArrayList<String> lore = new ArrayList<String>();
            lore.add(ChatColor.translateAlternateColorCodes('&', Main.getInstance().getConfig().getString("lock-pick-lore")));
            im.setLore(lore);
            is.setItemMeta(im);
            target.getInventory().addItem(is);
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&2[&aLockPick&2]"));
            sender.sendMessage("�aYou have sent a lock pick to " + playerName);
            target.sendMessage(ChatColor.translateAlternateColorCodes('&', "&2[&aLockPick&2]"));
            target.sendMessage("�aYou have received a lock pick!");
            return true;
        }
        return false;
    }
}
