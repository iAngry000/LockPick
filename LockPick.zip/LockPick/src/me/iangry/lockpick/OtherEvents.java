package me.iangry.lockpick;

import java.util.ArrayList;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;







public class OtherEvents
        implements Listener
{
    @EventHandler
    public void Place(BlockPlaceEvent e) {
        Player p = e.getPlayer();
        ItemStack is = new ItemStack(Material.getMaterial(Main.getInstance().getConfig().getString("lock-pick-item")));
        ItemMeta im = is.getItemMeta();
        im.setDisplayName(ChatColor.translateAlternateColorCodes('&', Main.getInstance().getConfig().getString("lock-pick-name")));
        im.addItemFlags(new ItemFlag[] { ItemFlag.HIDE_ENCHANTS });
        im.addEnchant(Enchantment.DAMAGE_ALL, 1, true);
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(ChatColor.translateAlternateColorCodes('&', Main.getInstance().getConfig().getString("lock-pick-lore")));
        im.setLore(lore);
        is.setItemMeta(im);
        if (p.getInventory().getItemInMainHand().getItemMeta().equals(im))
            e.setCancelled(true);
    }
}
