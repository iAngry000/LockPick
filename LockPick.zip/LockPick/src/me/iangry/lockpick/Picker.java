package me.iangry.lockpick;

import java.util.ArrayList;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.Sign;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;





public class Picker
        implements Listener
{
    @EventHandler
    public void onSignClick(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }

        Player p = e.getPlayer();
        if (p.hasPermission("lockpick.pick")) {
            ItemStack is = new ItemStack(Material.getMaterial(Main.getInstance().getConfig().getString("lock-pick-item")));
            ItemMeta im = is.getItemMeta();
            im.setDisplayName(ChatColor.translateAlternateColorCodes('&', Main.getInstance().getConfig().getString("lock-pick-name")));
            im.addItemFlags(new ItemFlag[] { ItemFlag.HIDE_ENCHANTS });
            im.addEnchant(Enchantment.DAMAGE_ALL, 1, true);
            ArrayList<String> lore = new ArrayList<String>();
            lore.add(ChatColor.translateAlternateColorCodes('&', Main.getInstance().getConfig().getString("lock-pick-lore")));
            im.setLore(lore);
            is.setItemMeta(im);
            if (p.getInventory().getItemInMainHand().getItemMeta().equals(im)) {

                if(!(e.getClickedBlock().getState() instanceof Sign)) return;
                Block b = e.getClickedBlock();
                Sign sign = (Sign) b.getState();

                if (ChatColor.stripColor(sign.getLine(0)).equalsIgnoreCase("[Private]"))
                if (ChatColor.stripColor(sign.getLine(0)).equalsIgnoreCase(Main.getInstance().getConfig().getString("lock-sign")));
                {

                    if (b.getType().name().contains("_SIGN") || b.getType().name().contains("_WALL_SIGN")) {


                        b.setType(Material.AIR);
                        p.sendMessage(ChatColor.translateAlternateColorCodes('&', Main.getInstance().getConfig().getString("lock-broken-message").replaceAll("%player%", p.getPlayer().getName())));
                        p.getInventory().getItemInMainHand().setAmount(p.getInventory().getItemInMainHand().getAmount() - 1);
                    }
                }
            }
        }
    }
}
