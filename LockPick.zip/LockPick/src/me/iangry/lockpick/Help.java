package me.iangry.lockpick;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;







public class Help
        implements CommandInterface
{
    public boolean onCommand(CommandSender sender, Command cmd, String commandLabel, String[] args) {
        Player p = (Player)sender;

        p.sendMessage(ChatColor.translateAlternateColorCodes('&', "&2[&aLockPick&2]"));
        p.sendMessage("�aCommands:");
        p.sendMessage("�7/LockPick");
        p.sendMessage("�7/LockPick Help");
        p.sendMessage("�7/LockPick Give <Player> <Amount>");
        p.sendMessage("�7/LockPick Reload");
        return false;
    }
}
