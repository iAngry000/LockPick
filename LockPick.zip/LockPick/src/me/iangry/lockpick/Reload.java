package me.iangry.lockpick;

import org.bukkit.ChatColor;
import org.bukkit.Instrument;
import org.bukkit.Note;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;


public class Reload
        implements CommandInterface {


    public boolean onCommand(CommandSender sender, Command cmd, String commandLabel, String[] args) {
        Player p = (Player) sender;
        if (p.hasPermission("lockpick.reload")) {
            p.sendMessage(ChatColor.translateAlternateColorCodes('&', "&2[&aLockPick&2]"));
            p.sendMessage("�7Reloading Plugin");
            Main.getInstance().reloadConfig();
            p.playNote(p.getLocation(), Instrument.CHIME, Note.natural(1, Note.Tone.A));
            p.sendMessage("�aReloaded Plugin");
            return true;
        }
        return false;
    }
}