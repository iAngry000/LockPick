package me.iangry.lockpick;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.event.Listener;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;


public class Main
        extends JavaPlugin
{
    private static Main instance;
    protected FileConfiguration config;

    public void registerCommands() {
        CommandHandler handler = new CommandHandler();


        handler.register("lockpick", new BaseCommand());


        handler.register("help", new Help());
        handler.register("Help", new Help());
        handler.register("give", new Get());
        handler.register("Give", new Get());
        handler.register("reload", new Reload());
        handler.register("Reload", new Reload());
        getCommand("lockpick").setExecutor(handler);
        PluginManager pm = getServer().getPluginManager();
        pm.registerEvents(new Picker(), this);
        pm.registerEvents(new OtherEvents(), this);
    }




    public void onEnable() {
        instance = this;
        registerCommands();
        getServer().getConsoleSender().sendMessage("�2[�aLockPick�2]");
        getServer().getConsoleSender().sendMessage("�a�lEnabled");
        getConfig().options().copyDefaults(true);
        saveConfig();

    }

    public void onDisable() {
        registerCommands();
        getServer().getConsoleSender().sendMessage("�2[�aLockPick�2]");
        getServer().getConsoleSender().sendMessage("�c�lDisabled");
        saveConfig();
    }

    public static Main getInstance() { return instance; }
}
